﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kr.Forms
{
    public partial class AddNewCustomer : Form
    {
        public AddNewCustomer()
        {
            InitializeComponent();
        }

        private void AddNewCustomer_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pK_TourfirmaDataSet.Customers". При необходимости она может быть перемещена или удалена.
            this.toursTableAdapter.Fill(this.pK_TourfirmaDataSet.Tours);
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            CustomersTable main = this.Owner as CustomersTable;
            if (main != null)
            {
                DataRow nRow = main.pK_TourfirmaDataSet.Tables[0].NewRow();
                nRow[0] = numericUpDownID.Value;
                nRow[1] = textBoxName.Text;
                nRow[2] = textBoxSurname.Text;
                nRow[3] = comboBoxPolet.SelectedValue;
                nRow[4] = numericUpDownLuggage.Value;

                main.pK_TourfirmaDataSet.Tables[0].Rows.Add(nRow);
                main.customersTableAdapter.Update(main.pK_TourfirmaDataSet.Customers);
                main.pK_TourfirmaDataSet.Tables[0].AcceptChanges();
                main.CustomersTable_Load(sender, e);
            }
        }

        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar) && e.KeyChar != Convert.ToChar(8))
            {
                e.Handled = true;
            }
        }
    }
}
