﻿using Kr.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kr
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void табличнаяФормаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomersTable form = new CustomersTable();
            form.Owner = this;
            form.Show();
        }

        private void добавитьЗаписьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomersTable form = new CustomersTable();
            form.Owner = this;
            form.Show();
            form.toolStripButtonAdd_Click(sender, e);
        }

        private void вызовСправкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox aboutProgrammForm = new AboutBox();
            aboutProgrammForm.ShowDialog();
        }

        private void оПрограммеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, helpProvider1.HelpNamespace);
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void выходныеДокументыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomersTable form = new CustomersTable();
            form.Owner = this;
            form.Show();
            form.toolStripButton1_Click(sender, e);
        }
    }
}
