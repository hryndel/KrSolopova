﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Kr.Forms
{
    public partial class CustomersTable : Form
    {
        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\PK_Tourfirma.mdf;Integrated Security=True";

        public CustomersTable()
        {
            InitializeComponent();
            ToolTip tip = new ToolTip();
            tip.SetToolTip(listBoxCriteri, "Выберите критерий для сортировки");
            tip.SetToolTip(radioButtonUp, "Сортировка критерия по возрастанию");
            tip.SetToolTip(radioButtonDown, "Сортировка критерия по убыванию");
            tip.SetToolTip(buttonSort, "Применить сортировку");
            tip.SetToolTip(comboBoxFiltr, "Выберите критерий для фильтрации");
        }

        public void CustomersTable_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pK_TourfirmaDataSet.Customers". При необходимости она может быть перемещена или удалена.
            this.customersTableAdapter.Fill(this.pK_TourfirmaDataSet.Customers);
            string query =
                "SELECT " +
                "[Customers].[IdCustomer], " +
                "[Customers].[Name], " +
                "[Customers].[Surname], " +
                "[Customers].[Luggage], " +
                "[Tours].[From], " +
                "[Tours].[Where], " +
                "[Tours].[Date] " +
                "FROM " +
                "[Customers], " +
                "[Tours] " +
                "WHERE " +
                "([Customers].[IdTour]=[Tours].[IdTour]) ";
            Zapros(query);
        }

        private void Zapros(string query)
        {
            dataGridViewTourfirma.Rows.Clear();

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[7]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
                data[data.Count - 1][4] = reader[4].ToString();
                data[data.Count - 1][5] = reader[5].ToString();
                data[data.Count - 1][6] = reader[6].ToString();
            }
            reader.Close();
            foreach (string[] s in data)
            {
                dataGridViewTourfirma.Rows.Add(s);
            }
            Status();
        }

        public void toolStripButtonAdd_Click(object sender, EventArgs e)
        {
            AddNewCustomer form = new AddNewCustomer();
            form.Owner = this;
            form.Show();
        }

        private void listBoxCriteri_SelectedIndexChanged(object sender, EventArgs e)
        {
            buttonSort.Enabled = true;
        }

        private System.Windows.Forms.DataGridViewColumn COL;
        private void buttonSort_Click(object sender, EventArgs e)
        {
            switch (listBoxCriteri.SelectedIndex)
            {
                case 0: COL = ColumnFrom;
                    break;
                case 1: COL = ColumnWhere;
                    break;
                case 2: COL = ColumnName;
                    break;
            }
            if (radioButtonDown.Checked)
                dataGridViewTourfirma.Sort(COL,System.ComponentModel.ListSortDirection.Ascending);
            else dataGridViewTourfirma.Sort(COL, System.ComponentModel.ListSortDirection.Descending);
        }

        private void comboBoxFiltr_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBoxFiltr.SelectedIndex)
            {
                case 0: CustomersTable_Load(sender, e);
                    break;
                case 1: FindByFromMoskov("From","Moskov");
                    break;
                case 2: FindByFromMoskov("Where", "Moskov");
                    break;
                case 3: FindByFromMoskov("From", "Saint-Petersburg");
                    break;
            }
        }
        private void FindByFromMoskov(string what, string value)
        {
            string query =
                "SELECT " +
                "[Customers].[IdCustomer], " +
                "[Customers].[Name], " +
                "[Customers].[Surname], " +
                "[Customers].[Luggage], " +
                "[Tours].[From], " +
                "[Tours].[Where], " +
                "[Tours].[Date] " +
                "FROM " +
                "[Customers], " +
                "[Tours] " +
                "WHERE " +
                "([Customers].[IdTour]=[Tours].[IdTour]) AND " +
                "([Tours].["+what+"]='"+value+"') ";
            //"([Tours].[From]=" + value + ") ";
            Zapros(query);
        }

        private void toolStripButtonDelete_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlCommand command = new SqlCommand("DELETE FROM [Customers] WHERE IdCustomer = @pId", connection); //TableName - имя таблицы, из которой удаляете запись
            command.Parameters.Add(new SqlParameter("@pId", this.dataGridViewTourfirma.CurrentRow.Cells["ColumnId"].Value)); //DataGridViewName - имя DataGridView на форме
            command.ExecuteNonQuery();
            connection.Close();
        }

        public void toolStripButton1_Click(object sender, EventArgs e)
        {
            var xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;

            //Книга
            Microsoft.Office.Interop.Excel.Workbook wBook;
            Microsoft.Office.Interop.Excel.Worksheet xlSheet;
            wBook = xlApp.Workbooks.Add();
            xlApp.Columns.ColumnWidth = 30;

            //Лист
            xlSheet = (Microsoft.Office.Interop.Excel.Worksheet)wBook.Sheets[1];
            //Присвоепние имени листа
            xlSheet.Name = "Клиенты";

            //Наименование ккаждого столбца
            xlSheet.Cells[1, 1] = "ID";
            xlSheet.Cells[1, 2] = "Имя";
            xlSheet.Cells[1, 3] = "Фамилия";
            xlSheet.Cells[1, 4] = "Багаж";
            xlSheet.Cells[1, 5] = "Откуда";
            xlSheet.Cells[1, 6] = "Куда";
            xlSheet.Cells[1, 7] = "Дата вылета";

            for (int i = 0; i < dataGridViewTourfirma.Rows.Count - 1; i++)
            {
                for (int j = 0; j < dataGridViewTourfirma.Columns.Count; j++)
                {
                    xlApp.Cells[i + 2, j + 1] = dataGridViewTourfirma.Rows[i].Cells[j].Value.ToString();
                }
            }
            xlSheet.Cells.HorizontalAlignment = 3;
            xlApp.Visible = true;
        }
        private void Status()
        {
            toolStripStatusLabel1.Text = (dataGridViewTourfirma.RowCount-1).ToString();
        }
    }
}
